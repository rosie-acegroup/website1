<?php
/**
 * PJECC one-page content.
 * Shared source of truth for the WordPress theme (index.php) and the
 * static preview (built with ../build-preview.php).
 *
 * Expects $asset — the base URL for /assets (no trailing slash).
 */
if ( ! isset( $asset ) ) { $asset = 'assets'; }
// Cache-bust photos by file-modification time so replaced images show right away.
$img_dir = __DIR__ . '/../assets/img';
$ver = function ( $file ) use ( $img_dir ) {
	$p = $img_dir . '/' . $file;
	return file_exists( $p ) ? '?v=' . filemtime( $p ) : '';
};
?>
<!-- ============================ NAV ============================ -->
<header class="nav" id="site-nav">
  <div class="nav__inner">
    <a class="nav__logo" href="#top" aria-label="PJECC home">
      <img src="<?php echo $asset; ?>/img/logo-horizontal.png<?php echo $ver('logo-horizontal.png'); ?>" alt="PJECC Palisades Jewish Early Childhood Center">
    </a>
    <nav class="nav__links" aria-label="Primary">
      <a href="#about">About</a>
      <a href="#why">Why PJECC</a>
      <a href="#programs">Programs</a>
      <a href="#philosophy">Philosophy</a>
      <a href="#visit">Visit</a>
      <a href="#faq">FAQ</a>
    </nav>
    <div class="nav__right">
      <a class="btn btn--sm" href="#enroll">Schedule a Tour</a>
      <button class="nav__toggle" aria-label="Toggle menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</header>

<!-- ============================ HERO ============================ -->
<section class="hero" id="top">
  <span class="shape shape--1"><svg viewBox="0 0 100 100"><path fill="#f8b7c9" d="M50 6c6 14 24 14 30 0-2 15 12 26 24 22-13 6-13 24 0 30-15-2-26 12-22 24-6-13-24-13-30 0 2-15-12-26-24-22 13-6 13-24 0-30 15 2 26-12 22-24z"/></svg></span>
  <span class="shape shape--2"><svg viewBox="0 0 100 100"><path fill="#8ccef1" d="M10 60c0-30 20-50 45-50 30 0 40 25 33 45-6 17 5 20-3 30-12 14-40 12-55-5C17 74 10 70 10 60z"/></svg></span>
  <span class="shape shape--3"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="44" fill="#96be3d"/></svg></span>
  <span class="shape shape--4"><svg viewBox="0 0 100 60"><path fill="#004623" d="M4 56C4 26 24 4 50 4s46 22 46 52H74c0-16-10-28-24-28S26 40 26 56z"/></svg></span>
  <span class="shape shape--5"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="44" fill="#ffeb83"/></svg></span>
  <span class="shape shape--6"><svg viewBox="0 0 100 100"><path fill="#306cb5" d="M50 4c8 20 26 20 34 0-4 20 14 34 30 26-16 12-16 34 0 46-16-8-34 6-30 26-8-20-26-20-34 0 4-20-14-34-30-26 16-12 16-34 0-46 16 8 34-6 30-26z"/></svg></span>

  <img class="hero__bubble hero__bubble--3" src="<?php echo $asset; ?>/img/bubble-3.jpg<?php echo $ver('bubble-3.jpg'); ?>" alt="" aria-hidden="true">
  <img class="hero__bubble hero__bubble--4" src="<?php echo $asset; ?>/img/bubble-4.jpg<?php echo $ver('bubble-4.jpg'); ?>" alt="" aria-hidden="true">
  <img class="hero__bubble hero__bubble--1" src="<?php echo $asset; ?>/img/bubble-1.jpg<?php echo $ver('bubble-1.jpg'); ?>" alt="" aria-hidden="true">
  <img class="hero__bubble hero__bubble--2" src="<?php echo $asset; ?>/img/bubble-2.jpg<?php echo $ver('bubble-2.jpg'); ?>" alt="" aria-hidden="true">

  <div class="hero__inner">
    <img class="hero__tree" src="<?php echo $asset; ?>/img/tree-submark.png" alt="">
    <h1 class="hero__title">Two Campuses,<br>One <em>Community.</em></h1>
    <p class="hero__lead">A warm, nature-inspired Jewish early childhood community where every child is known, every family belongs, and children are celebrated in all the ways that matter most.</p>
    <div class="hero__cta">
      <a class="btn" href="#enroll">Schedule a Tour</a>
      <a class="btn btn--ghost" href="#programs">Explore Programs</a>
    </div>
  </div>
</section>

<!-- ==================== TAGLINE + STATS ==================== -->
<section class="strip">
  <div class="wrap">
    <p class="strip__tag">A community that holds you.</p>
    <div class="stats">
      <div><span>20+</span><small>Years of joyful beginnings</small></div>
      <div><span>2</span><small>Palisades &amp; Franklin campuses</small></div>
      <div><span class="stat--sm">3 Months–5 Years</span><small>Infants through TK</small></div>
      <div><span class="stat--sm">Rooted in Nature</span><small>Centered on children</small></div>
    </div>
  </div>
</section>

<!-- ============================ ABOUT ============================ -->
<section class="section" id="about">
  <div class="wrap">
    <div class="about__grid">
      <div class="about__copy reveal">
        <h2 class="section-title">Where Strong Beginnings<br>Take Root.</h2>
        <p class="section-sub" style="margin:1rem 0 1.6rem;">The Palisades welcomes PJECC back,<br>stronger than ever.</p>
        <p>Over 20 years ago, Chabad of the Pacific Palisades opened PJECC with a simple vision: a place where children could grow in an environment filled with warmth, curiosity, beauty, and genuine care. As our school grew, so did that vision, slowly shaping a campus and classrooms that feel alive with childhood.</p>
        <p>After the Palisades fires forced a temporary move to our Franklin campus, what began as a crisis response grew into an expansion. Today we're entering a new chapter: reopening our Palisades campus while continuing to nurture our Franklin community, serving both and welcoming new families.</p>
        <p>Through it all, our purpose has stayed the same: to create a place where every child is known, every family feels welcome, and childhood is celebrated in all the ways that matter most.</p>
      </div>
      <div class="media media--tall reveal">
        <img src="<?php echo $asset; ?>/img/about.jpg<?php echo $ver('about.jpg'); ?>" alt="A child in a PJECC shirt playing on the tree">
      </div>
    </div>
  </div>
</section>

<!-- ==================== PHOTO BAND (before Why) ==================== -->
<section class="photoband reveal">
  <div class="wrap">
    <img src="<?php echo $asset; ?>/img/why-banner.jpg<?php echo $ver('why-banner.jpg'); ?>" alt="A child playing at the water pump at PJECC">
  </div>
</section>

<!-- ============================ WHY ============================ -->
<section class="section section--alt" id="why">
  <div class="wrap">
    <div class="section__head reveal">
      <h2 class="section-title">Why PJECC</h2>
      <p class="lead">Children aren't just cared for or just taught, they're genuinely guided to become thinkers, explorers, and confident individuals. Here's what makes childhood at PJECC different.</p>
    </div>
    <div class="cards">
      <article class="card reveal">
        <div class="card__icon i-lime"><svg viewBox="0 0 24 24" fill="none" stroke="#20360f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z"/><path d="M9 12l2 2 4-4"/></svg></div>
        <h3>Reggio-Inspired</h3>
        <p>Children are the driving force behind what they learn, engaging in collaborative, joyful discovery that builds curiosity and resilience.</p>
      </article>
      <article class="card reveal">
        <div class="card__icon i-blue"><svg viewBox="0 0 24 24" fill="none" stroke="#255491" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M12 8c-3-4-8-3-9 1 4 1 6 4 9 3z"/><path d="M12 8c3-4 8-3 9 1-4 1-6 4-9 3z"/></svg></div>
        <h3>Rooted in Nature</h3>
        <p>One of the few outdoor Jewish preschools by the coast, a natural landscape of grass fields, gardens, and play built by the hands of our community.</p>
      </article>
      <article class="card reveal">
        <div class="card__icon i-pink"><svg viewBox="0 0 24 24" fill="none" stroke="#004623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.5-7 10-7 10z"/></svg></div>
        <h3>Jewish Values, Woven In</h3>
        <p>Judaism lives naturally in the rhythm of each day, nurturing kindness, respect, and a joyful connection to heritage, with every family welcomed.</p>
      </article>
      <article class="card reveal">
        <div class="card__icon i-yellow"><svg viewBox="0 0 24 24" fill="none" stroke="#5a4a10" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.5"/><path d="M2 21c0-3.5 3-6 7-6s7 2.5 7 6"/><path d="M16 4a3.5 3.5 0 0 1 0 7"/><path d="M22 21c0-2.6-1.5-4.7-4-5.6"/></svg></div>
        <h3>Small Classes, Low Ratios</h3>
        <p>Small classes with low student-to-teacher ratios, led by specialists in early childhood development who know each child deeply.</p>
      </article>
      <article class="card reveal">
        <div class="card__icon i-green"><svg viewBox="0 0 24 24" fill="none" stroke="#004623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15s2-6 8-6 8 6 8 6"/><circle cx="12" cy="6" r="0"/><path d="M8 20c1.5-2 6.5-2 8 0"/><path d="M12 9v6"/></svg></div>
        <h3>Play-Based &amp; Joyful</h3>
        <p>Children learn best when they're having fun. We honor childhood rather than rush it, inspiring wonder through play, art, music, and exploration.</p>
      </article>
      <article class="card reveal">
        <div class="card__icon i-deep"><svg viewBox="0 0 24 24" fill="none" stroke="#f9f4e7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="9" r="3"/><circle cx="16" cy="9" r="3"/><path d="M2 20c0-3 2.5-5 6-5"/><path d="M22 20c0-3-2.5-5-6-5"/><path d="M9 20c0-2 1.5-3 3-3s3 1 3 3"/></svg></div>
        <h3>A Real Community</h3>
        <p>We invest as deeply in our teachers and families as we do in our children. It's not just a program. It's a place that feels like family.</p>
      </article>
    </div>
  </div>
</section>

<!-- ============================ PROGRAMS ============================ -->
<section class="section" id="programs">
  <div class="wrap">
    <div class="section__head reveal">
      <h2 class="section-title">Our Classes</h2>
      <p class="lead">Where your child's story begins. From first steps to their leap toward kindergarten, every class meets children exactly where they are, with warmth, wonder, and room to grow.</p>
    </div>
    <div class="programs">
      <article class="program program--pink reveal">
        <p class="program__age">Chaverim Alef</p>
        <h3>Infant Center</h3>
        <p>A warm, loving first home away from home. Through responsive care, sensory play, music, and meaningful relationships, we build trust, connection, and a lifelong love of learning from the very beginning.</p>
      </article>
      <article class="program program--sky reveal">
        <p class="program__age">Chaverim Bet</p>
        <h3>Toddlers</h3>
        <p>Curiosity comes alive. Children explore outdoors, create, climb, and build friendships through purposeful play, growing in confidence, independence, language, and social-emotional skills.</p>
      </article>
      <article class="program program--lime reveal">
        <p class="program__age">Chaverim Gimmel</p>
        <h3>2-Year-Olds</h3>
        <p>Imagination takes center stage. Through open-ended materials, art, storytelling, and dramatic play, children develop creativity, communication, and a joyful love of learning.</p>
      </article>
      <article class="program program--yellow reveal">
        <p class="program__age">Chaverim Daled</p>
        <h3>3-Year-Olds</h3>
        <p>Deeper discovery through investigations inspired by nature, literature, and Jewish traditions, encouraging collaboration, critical thinking, and the confidence to explore new ideas.</p>
      </article>
      <article class="program program--green reveal">
        <p class="program__age">Chaverim Hey</p>
        <h3>4-Year-Olds / TK</h3>
        <p>Our oldest learners are confident, capable, and ready to lead. Alongside creative, purposeful play, they build a strong foundation in literacy, math, and problem-solving, ready for kindergarten and beyond.</p>
      </article>
      <a class="program program--blue reveal" href="#enroll" style="text-decoration:none;">
        <h3>Come See Us<br>in Action</h3>
        <p>Schedule a tour and we'll help you find your child's class, and let you feel the community for yourself. →</p>
      </a>
    </div>
  </div>
</section>

<!-- ============================ PHILOSOPHY ============================ -->
<section class="section section--alt" id="philosophy">
  <div class="wrap">
    <div class="philosophy__grid">
      <div class="media philosophy__photo reveal">
        <img src="<?php echo $asset; ?>/img/philosophy.jpg<?php echo $ver('philosophy.jpg'); ?>" alt="Children building with wooden blocks and crates at PJECC">
      </div>
      <div class="philosophy reveal">
        <p class="eyebrow">Our Philosophy</p>
        <blockquote>Educate a child <span>according to his way.</span></blockquote>
        <p>At PJECC, we believe childhood is meant to be joyful. Every child is seen as an individual, full of curiosity, creativity, and endless potential. Our role is to create an environment where children feel safe to explore, ask questions, build friendships, and discover the world around them. We honor childhood rather than rush it.</p>
        <p class="philosophy__cite">The Torah's teaching, at the heart of everything we do</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================ CAMPUSES ============================ -->
<section class="section" id="visit">
  <div class="wrap">
    <div class="section__head reveal">
      <h2 class="section-title">Two Campuses.<br>One Community.</h2>
      <p class="lead">Rooted in the same values, warmth, and excellence our families have trusted for generations, now welcoming children across two campuses.</p>
    </div>
    <div class="campuses">
      <article class="campus reveal">
        <div class="campus__banner">
          <img class="campus__img" src="<?php echo $asset; ?>/img/campus-palisades.jpg<?php echo $ver('campus-palisades.jpg'); ?>" alt="A child playing at the Palisades Campus">
          <span class="campus__tag">Now Enrolling</span>
        </div>
        <div class="campus__body">
          <h3>Palisades Campus</h3>
          <p>Our founding home in the Pacific Palisades, a natural, sun-filled campus of gardens, grass fields, and play, back and stronger than ever for the 2026–2027 school year.</p>
          <p class="campus__addr"><a href="https://maps.google.com/?q=17315+Sunset+Blvd,+Pacific+Palisades,+CA+90272" target="_blank" rel="noopener">17315 Sunset Blvd, Pacific Palisades, CA 90272</a></p>
          <a class="link" href="#enroll">Schedule a tour →</a>
        </div>
      </article>
      <article class="campus reveal">
        <div class="campus__banner">
          <img class="campus__img" src="<?php echo $asset; ?>/img/campus-franklin.jpg<?php echo $ver('campus-franklin.jpg'); ?>" alt="Two children on the tire swing at the Franklin Campus">
          <span class="campus__tag">Now Enrolling</span>
        </div>
        <div class="campus__body">
          <h3>Franklin Campus</h3>
          <p>The warm community that grew from our new chapter, now serving Franklin families with the same nurturing, individualized approach PJECC is known for.</p>
          <p class="campus__addr"><a href="https://maps.google.com/?q=1537+Franklin+St,+Santa+Monica,+CA+90404" target="_blank" rel="noopener">1537 Franklin St, Santa Monica, CA 90404</a></p>
          <a class="link" href="#enroll">Schedule a tour →</a>
        </div>
      </article>
    </div>
  </div>
</section>

<!-- ============================ TESTIMONIAL ============================ -->
<section class="section section--alt">
  <div class="wrap">
    <div class="quote reveal">
      <p>It's the school where kids actually love going. They learn so much, but it never feels like pressure, it feels like joy. And the community? It's like family.</p>
      <cite>A PJECC Parent</cite>
    </div>
  </div>
</section>

<!-- ============================ FAQ ============================ -->
<section class="section" id="faq">
  <div class="wrap">
    <div class="section__head reveal" style="text-align:center;margin-left:auto;margin-right:auto;">
      <h2 class="section-title" style="color:var(--blue);">Frequently Asked<br>Questions.</h2>
    </div>
    <div class="faq reveal">
      <details class="faq__item" open>
        <summary>What's the heart of PJECC?</summary>
        <div class="faq__a">
          <p>Not at all. PJECC is open to families of all backgrounds. What unites our families is the desire to raise thoughtful, confident children who feel loved, respected, and connected. Jewish values are woven naturally into each day, nurturing kindness, respect, and belonging for every child.</p>
        </div>
      </details>
      <details class="faq__item">
        <summary>What are your hours and schedule options?</summary>
        <div class="faq__a">
          <p>We offer flexible scheduling to fit your family:</p>
          <ul>
            <li><strong>Half day</strong>: 9:00 AM–12:30 PM</li>
            <li><strong>Full day</strong>: 9:00 AM–3:00 PM</li>
            <li><strong>Extended care</strong>: 7:30–9:00 AM &amp; 3:00–5:30 PM</li>
          </ul>
        </div>
      </details>
      <details class="faq__item">
        <summary>What ages do you serve?</summary>
        <div class="faq__a">
          <p>We welcome children from infancy through TK (about 0–5 years), across five age groups, our Chaverim classes:</p>
          <ul>
            <li><strong>Chaverim Alef</strong>: Infant Center</li>
            <li><strong>Chaverim Bet</strong>: Toddlers</li>
            <li><strong>Chaverim Gimmel</strong>: 2-Year-Olds</li>
            <li><strong>Chaverim Daled</strong>: 3-Year-Olds</li>
            <li><strong>Chaverim Hey</strong>: 4-Year-Olds / TK</li>
          </ul>
        </div>
      </details>
      <details class="faq__item">
        <summary>Where are your two campuses?</summary>
        <div class="faq__a">
          <p>We have two locations:</p>
          <ul>
            <li><strong>Palisades Campus</strong>: 17315 Sunset Blvd, Pacific Palisades, CA 90272</li>
            <li><strong>Franklin Campus</strong>: 1537 Franklin St, Santa Monica, CA 90404</li>
          </ul>
        </div>
      </details>
      <details class="faq__item">
        <summary>What is your educational approach?</summary>
        <div class="faq__a">
          <p>We're a Reggio-inspired, play-based program, one of the few outdoor Jewish preschools by the coast. Children learn through play, nature, art, and discovery in small classes with low student-to-teacher ratios, guided by specialists in early childhood development. We honor childhood rather than rush it.</p>
        </div>
      </details>
      <details class="faq__item">
        <summary>How do I apply or schedule a tour?</summary>
        <div class="faq__a">
          <p>The best first step is to come see us. <a href="#enroll" style="color:var(--blue);font-weight:700;">Schedule a tour</a> using the form below, or reach out at <a href="mailto:info@pjecc.org" style="color:var(--blue);font-weight:700;">info@pjecc.org</a>. We're now enrolling for the 2026–2027 school year at both campuses.</p>
        </div>
      </details>
    </div>
  </div>
</section>

<!-- ============================ CTA BAND ============================ -->
<section class="section">
  <div class="wrap">
    <div class="cta reveal">
      <p class="eyebrow" style="color:var(--yellow);font-family:var(--f-body);font-style:normal;font-weight:700;text-transform:uppercase;letter-spacing:0.28em;font-size:13px;">Join Us This Fall</p>
      <h2>Where Your Child's<br>Story Begins.</h2>
      <p>PJECC is growing, and we'd love for you to be part of it from the very beginning.</p>
      <div class="cta__btns">
        <a class="btn btn--light" href="#enroll">Schedule a Tour</a>
        <a class="btn btn--ghost" style="color:var(--cream);border-color:var(--cream);" href="#enroll">Enroll for 2026–2027</a>
      </div>
    </div>
  </div>
</section>

<!-- ============================ ENROLL / VISIT FORM ============================ -->
<section class="section" id="enroll">
  <div class="wrap">
    <div class="enroll__grid">
      <div class="reveal">
        <h2 class="section-title">Schedule a Tour.</h2>
        <p class="lead" style="margin-bottom:2rem;">If you're considering enrolling for the 2026–2027 school year, now is the moment. Come see the space, meet our educators, and experience the community that makes PJECC so special.</p>
        <ul class="contact-list">
          <li>
            <span class="ci"><svg viewBox="0 0 24 24" fill="none" stroke="#255491" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z"/><path d="m4 6 8 6 8-6"/></svg></span>
            <span><strong>Email</strong><a href="mailto:info@pjecc.org">info@pjecc.org</a></span>
          </li>
          <li>
            <span class="ci"><svg viewBox="0 0 24 24" fill="none" stroke="#255491" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-3 2a12 12 0 0 0 5 5l2-3 5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg></span>
            <span><strong>Call</strong><a href="tel:+13103836584">(310) 383-6584</a></span>
          </li>
          <li>
            <span class="ci"><svg viewBox="0 0 24 24" fill="none" stroke="#255491" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s7-6 7-11a7 7 0 1 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/></svg></span>
            <span><strong>Campuses</strong><span>Palisades: 17315 Sunset Blvd<br>Franklin: 1537 Franklin St, Santa Monica</span></span>
          </li>
        </ul>
      </div>
      <div class="form-card reveal">
        <form id="tour-form" action="https://api.web3forms.com/submit" method="POST">
          <?php $pjecc_form_key = ( defined( 'PJECC_FORM_KEY' ) && PJECC_FORM_KEY ) ? PJECC_FORM_KEY : 'afa86c20-0c9c-47df-8db7-9be98be80366'; ?>
          <input type="hidden" name="access_key" value="<?php echo function_exists( 'esc_attr' ) ? esc_attr( $pjecc_form_key ) : htmlspecialchars( $pjecc_form_key ); ?>">
          <input type="hidden" name="subject" value="New Preschool Inquiry from the PJECC website">
          <input type="hidden" name="from_name" value="PJECC Website">
          <?php if ( function_exists( 'home_url' ) ) : ?><input type="hidden" name="redirect" value="<?php echo esc_url( home_url( '/?tour=sent#enroll' ) ); ?>"><?php endif; ?>
          <!-- Spam honeypot (Web3Forms botcheck) -->
          <input type="checkbox" name="botcheck" class="pjecc-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
          <div class="field-row">
            <div class="field">
              <label for="child_first">Child's First Name(s)</label>
              <input id="child_first" name="Child's First Name(s)" type="text" required>
            </div>
            <div class="field">
              <label for="child_last">Child's Last Name</label>
              <input id="child_last" name="Child's Last Name" type="text" required>
            </div>
          </div>
          <div class="field-row">
            <div class="field">
              <label for="child_dob">Child's Date of Birth</label>
              <input id="child_dob" name="Child's Date of Birth" type="date">
            </div>
            <div class="field">
              <label for="gender">Gender</label>
              <select id="gender" name="Gender">
                <option value="">Select…</option>
                <option>Boy</option>
                <option>Girl</option>
                <option>Prefer not to say</option>
              </select>
            </div>
          </div>
          <div class="field-row">
            <div class="field">
              <label for="parent_first">Applying Parent's First Name</label>
              <input id="parent_first" name="Applying Parent's First Name" type="text" autocomplete="given-name" required>
            </div>
            <div class="field">
              <label for="parent_last">Applying Parent's Last Name</label>
              <input id="parent_last" name="Applying Parent's Last Name" type="text" autocomplete="family-name" required>
            </div>
          </div>
          <div class="field">
            <label for="parent2_first">Second Parent's First Name</label>
            <input id="parent2_first" name="Second Parent's First Name" type="text">
          </div>
          <div class="field-row">
            <div class="field">
              <label for="email">Applying Parent's Email Address</label>
              <input id="email" name="email" type="email" autocomplete="email" required>
            </div>
            <div class="field">
              <label for="parent2_email">Second Parent's Email Address</label>
              <input id="parent2_email" name="Second Parent's Email Address" type="email">
            </div>
          </div>
          <div class="field">
            <label for="street">Street Address</label>
            <input id="street" name="Street Address" type="text" autocomplete="street-address">
          </div>
          <div class="field-row">
            <div class="field">
              <label for="citystatezip">City, State &amp; Zip Code</label>
              <input id="citystatezip" name="City, State &amp; Zip Code" type="text">
            </div>
            <div class="field">
              <label for="phone">Phone Number</label>
              <input id="phone" name="Phone Number" type="tel" autocomplete="tel">
            </div>
          </div>
          <div class="field">
            <label for="start_date">Desired Start Date</label>
            <input id="start_date" name="Desired Start Date" type="text" placeholder="e.g. Fall 2026">
          </div>
          <div class="field">
            <label for="hear">How did you hear about us?</label>
            <input id="hear" name="How did you hear about us?" type="text">
          </div>
          <div class="field">
            <label for="fire_impact">Have you been impacted by the Palisades Fire, lost your home, or been displaced? (Please specify.)</label>
            <textarea id="fire_impact" name="Palisades Fire Impact" rows="2"></textarea>
          </div>
          <div class="field">
            <label for="contact_pref">Do you prefer to be contacted by email or phone?</label>
            <select id="contact_pref" name="Preferred Contact Method">
              <option value="">Select…</option>
              <option>Email</option>
              <option>Phone</option>
            </select>
          </div>
          <p class="form-sub">Tour Scheduling</p>
          <div class="field">
            <label for="comments">Comments</label>
            <textarea id="comments" name="Comments" rows="3"></textarea>
          </div>
          <button class="btn" type="submit" style="width:100%;justify-content:center;">Request a Tour</button>
<?php if ( ! empty( $_GET['tour'] ) && 'sent' === $_GET['tour'] ) : ?>
          <p class="form-note" style="margin-top:1rem;color:var(--green);font-weight:700;">Thank you! Your request is on its way, we'll be in touch soon. 🌳</p>
<?php endif; ?>
          <p class="form-note form-note--js" hidden style="margin-top:1rem;color:var(--green);font-weight:700;">Thank you! We'll be in touch soon. 🌳</p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ============================ FOOTER ============================ -->
<footer class="footer">
  <div class="wrap">
    <div class="footer__grid">
      <div class="footer__logo">
        <img src="<?php echo $asset; ?>/img/logo-primary.png" alt="PJECC Palisades Jewish Early Childhood Center">
        <p>A Chabad-affiliated Jewish early childhood center serving infants through TK, open to families of all backgrounds. We're home. And so are you.</p>
        <div class="footer__social">
          <a href="https://www.instagram.com/pjecc/" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="#f9f4e7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="#f9f4e7" stroke="none"/></svg></a>
          <a href="https://www.facebook.com/PJECC" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24" fill="none" stroke="#f9f4e7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h-3a4 4 0 0 0-4 4v3H5v4h3v7h4v-7h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a href="mailto:info@pjecc.org" aria-label="Email"><svg viewBox="0 0 24 24" fill="none" stroke="#f9f4e7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z"/><path d="m4 6 8 6 8-6"/></svg></a>
        </div>
      </div>
      <div>
        <h4>Explore</h4>
        <ul>
          <li><a href="#about">Our Story</a></li>
          <li><a href="#why">Why PJECC</a></li>
          <li><a href="#programs">Programs</a></li>
          <li><a href="#philosophy">Philosophy</a></li>
          <li><a href="#enroll">Schedule a Tour</a></li>
        </ul>
      </div>
      <div>
        <h4>Visit</h4>
        <ul>
          <li><a href="#visit">Palisades Campus</a></li>
          <li><a href="#visit">Franklin Campus</a></li>
          <li><a href="mailto:info@pjecc.org">info@pjecc.org</a></li>
          <li><a href="tel:+13103836584">(310) 383-6584</a></li>
        </ul>
      </div>
    </div>
    <div class="footer__bottom">
      <span>&copy; <?php echo function_exists('date') ? date('Y') : '2026'; ?> Palisades Jewish Early Childhood Center. All rights reserved.</span>
      <span>Branding &amp; site by <a href="https://acegroupny.com" target="_blank" rel="noopener">The Ace Group</a></span>
    </div>
  </div>
</footer>
